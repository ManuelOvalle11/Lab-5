/*
 * IncFile1.h
 *
 * Created: 17/04/2024 17:04:06
 *  Author: Ovall
 */ 


#ifndef PMW_2_H_
#define PMW_2_H_
#include <stdint.h>
#include <avr/io.h>

void init_PMW_2A(int orientacion,int modo,int preescaler);
void init_PMW_2B(int orientacion);
void duty_cycleA(int duty);
void duty_cycleB(int duty);

#endif /* PMW0_H_ */